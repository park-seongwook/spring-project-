package com.javalec.friendsourcing.dto;

public class placeDto {
	private int plaNum;
	private String plaName;
	private double plaX;
	private double plaY;
	private FeedDto feedDto;
	
	public placeDto() {
	}
	
	public placeDto(int plaNum, String plaName, double plaX, double plaY) {
		this.plaNum = plaNum;
		this.plaName = plaName;
		this.plaX = plaX;
		this.plaY = plaY;
	}
	public FeedDto getFeedDto() {
		return feedDto;
	}
	
	public void setFeedDto(FeedDto feedDto) {
		this.feedDto = feedDto;
	}
	public int getPlaNum() {
		return plaNum;
	}
	public void setPlaNum(int plaNum) {
		this.plaNum = plaNum;
	}
	public String getPlaName() {
		return plaName;
	}
	public void setPlaName(String plaName) {
		this.plaName = plaName;
	}
	public double getPlaX() {
		return plaX;
	}
	public void setPlaX(double plaX) {
		this.plaX = plaX;
	}
	public double getPlaY() {
		return plaY;
	}
	public void setPlaY(double plaY) {
		this.plaY = plaY;
	}
}
