package com.javalec.friendsourcing.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.javalec.friendsourcing.dto.FeedDto;
import com.javalec.friendsourcing.dto.FollowDto;

@Service
public interface serviceTG {
	public void fileUpload(String uploadpath,String uuid,String filename,String memId);
	public void FeedUpload(HashMap<String, String> param);
	public String feedNum();
	public String feedCount();
	public int feedFollow(HashMap<String, String> param);
	public String[] followListView(HashMap<String, String> param);
	public int followDelete(HashMap<String, String> param);
	
	public ArrayList<FeedDto> feedList(int startRowNum,int endRowNum);
	public ArrayList<FeedDto> followfeedList(HashMap<String, Object> param); 
	public ArrayList<FeedDto> myLikeFeedList(HashMap<String, Object> param);
	public ArrayList<FeedDto> myFeedList(HashMap<String, Object> param);
	public ArrayList<FeedDto> myTagFeedList(HashMap<String, Object> param);
	public void tagInsert(HashMap<String, String> param);
	public void hashtagInsert(HashMap<String, String> param);
}
