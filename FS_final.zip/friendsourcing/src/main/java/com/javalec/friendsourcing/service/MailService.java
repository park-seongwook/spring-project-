package com.javalec.friendsourcing.service;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.javalec.friendsourcing.dto.email;

@Service
public class MailService {
	
	@Autowired
	private JavaMailSender mailSender;
	
	
	public void sendEmail(email email) throws Exception{
		MimeMessage msg = mailSender.createMimeMessage();
		
		try {
			msg.setSubject(email.getTitle());
			msg.setText(email.getContent());
			msg.setRecipients(MimeMessage.RecipientType.TO, InternetAddress.parse(email.getReciver()));
			
		} catch (Exception e) {
			System.out.println("�޼��� ����");
			e.printStackTrace();
		}
		
		try {
			mailSender.send(msg);
		} catch (Exception e) {
			System.out.println("���� ����");
			e.printStackTrace();
		}
	}
}
